from pathlib import Path

from PIL import Image


TESTS_DIRECTORY = Path(__file__).resolve().parent

cover_path = TESTS_DIRECTORY / "cover.png"
tiny_path = TESTS_DIRECTORY / "tiny.png"

cover_image = Image.new(
    mode="RGB",
    size=(800, 500),
    color=(30, 110, 160)
)
cover_image.save(cover_path, format="PNG")

tiny_image = Image.new(
    mode="RGB",
    size=(1, 1),
    color=(0, 0, 0)
)
tiny_image.save(tiny_path, format="PNG")

print(f"Created: {cover_path}")
print(f"Created: {tiny_path}")