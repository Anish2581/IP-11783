import contextlib
import hashlib
import io
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

import stego


class SteganographyTests(unittest.TestCase):

    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.test_folder = Path(self.temp_directory.name)

        self.cover_image = self.test_folder / "cover.png"
        self.encoded_image = self.test_folder / "encoded.png"

        Image.new(
            "RGB",
            (800, 500),
            (30, 110, 160)
        ).save(self.cover_image)

    def tearDown(self):
        self.temp_directory.cleanup()

    @staticmethod
    def sha256(file_path):
        digest = hashlib.sha256()

        with open(file_path, "rb") as file:
            for block in iter(lambda: file.read(65536), b""):
                digest.update(block)

        return digest.hexdigest()

    def test_encode_and_exact_decode_round_trip(self):
        message = "Cloud Counselage Internship Program"

        stego.encode(
            self.cover_image,
            self.encoded_image,
            message
        )

        output = io.StringIO()

        with contextlib.redirect_stdout(output):
            stego.decode(self.encoded_image)

        self.assertEqual(output.getvalue().strip(), message)

    def test_original_image_sha256_integrity(self):
        hash_before = self.sha256(self.cover_image)

        stego.encode(
            self.cover_image,
            self.encoded_image,
            "Integrity test"
        )

        hash_after = self.sha256(self.cover_image)

        self.assertEqual(hash_before, hash_after)

    def test_encoded_image_dimensions_are_preserved(self):
        stego.encode(
            self.cover_image,
            self.encoded_image,
            "Dimension test"
        )

        with Image.open(self.cover_image) as original:
            original_size = original.size

        with Image.open(self.encoded_image) as encoded:
            encoded_size = encoded.size

        self.assertEqual(original_size, encoded_size)

    def test_unencoded_image_is_rejected(self):
        with self.assertRaisesRegex(
            ValueError,
            "No supported hidden message was found"
        ):
            stego.decode(self.cover_image)

    def test_original_image_overwrite_is_rejected(self):
        with self.assertRaisesRegex(
            ValueError,
            "Output must not overwrite the original image"
        ):
            stego.encode(
                self.cover_image,
                self.cover_image,
                "Overwrite test"
            )

    def test_insufficient_capacity_is_rejected(self):
        tiny_image = self.test_folder / "tiny.png"
        tiny_output = self.test_folder / "tiny-encoded.png"

        Image.new("RGB", (1, 1), (0, 0, 0)).save(tiny_image)

        with self.assertRaisesRegex(
            ValueError,
            "Message is too large"
        ):
            stego.encode(
                tiny_image,
                tiny_output,
                "Cloud Counselage Internship Program"
            )

    def test_sha256_manifest_verification(self):
        files = [
            PROJECT_ROOT / "src" / "stego.py",
            PROJECT_ROOT / "requirements.txt"
        ]

        manifest = {
            str(file.relative_to(PROJECT_ROOT)): self.sha256(file)
            for file in files
        }

        for relative_path, expected_hash in manifest.items():
            actual_hash = self.sha256(PROJECT_ROOT / relative_path)
            self.assertEqual(actual_hash, expected_hash)


if __name__ == "__main__":
    unittest.main(verbosity=2)