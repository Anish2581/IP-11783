#!/usr/bin/env python3

import argparse
import struct
import sys
from pathlib import Path

from PIL import Image


MAGIC = b"STEGOV1"
LENGTH_SIZE = 4
HEADER_SIZE = len(MAGIC) + LENGTH_SIZE


def bytes_to_bits(data):
    """Convert bytes into a sequence of individual bits."""
    for byte in data:
        for position in range(7, -1, -1):
            yield (byte >> position) & 1


def bits_to_bytes(bits):
    """Convert a sequence of bits back into bytes."""
    output = bytearray()

    for index in range(0, len(bits), 8):
        group = bits[index:index + 8]

        if len(group) < 8:
            break

        value = 0
        for bit in group:
            value = (value << 1) | bit

        output.append(value)

    return bytes(output)


def load_rgb_image(image_path):
    """Open an image and convert it to RGB format."""
    try:
        return Image.open(image_path).convert("RGB")
    except (OSError, ValueError) as error:
        raise ValueError(f"Unable to open image: {error}") from error


def calculate_capacity(image):
    """Return the maximum message capacity in bytes."""
    total_colour_channels = image.width * image.height * 3
    total_bytes = total_colour_channels // 8
    return max(0, total_bytes - HEADER_SIZE)


def encode(input_path, output_path, message):
    """Hide a UTF-8 message inside an image using LSB encoding."""
    source = Path(input_path).expanduser().resolve()
    destination = Path(output_path).expanduser().resolve()

    if source == destination:
        raise ValueError("Output must not overwrite the original image.")

    if destination.suffix.lower() != ".png":
        raise ValueError("The encoded output must use the PNG format.")

    image = load_rgb_image(source)
    message_bytes = message.encode("utf-8")
    capacity = calculate_capacity(image)

    if len(message_bytes) > capacity:
        raise ValueError(
            f"Message is too large. Maximum capacity is {capacity} bytes."
        )

    data = MAGIC + struct.pack(">I", len(message_bytes)) + message_bytes
    bits = list(bytes_to_bits(data))

    channels = list(image.tobytes())

    for index, bit in enumerate(bits):
        channels[index] = (channels[index] & 0xFE) | bit

    encoded_image = Image.frombytes("RGB", image.size, bytes(channels))
    destination.parent.mkdir(parents=True, exist_ok=True)
    encoded_image.save(destination, format="PNG")

    print(f"Message encoded successfully: {destination}")
    print(f"Message length: {len(message_bytes)} bytes")
    print(f"Image capacity: {capacity} bytes")


def decode(input_path):
    """Extract and print a hidden UTF-8 message from an image."""
    source = Path(input_path).expanduser().resolve()
    image = load_rgb_image(source)

    channels = list(image.tobytes())
    header_bit_count = HEADER_SIZE * 8

    if len(channels) < header_bit_count:
        raise ValueError("No supported hidden message was found.")

    header_bits = [channel & 1 for channel in channels[:header_bit_count]]
    header = bits_to_bytes(header_bits)

    if header[:len(MAGIC)] != MAGIC:
        raise ValueError("No supported hidden message was found.")

    message_length = struct.unpack(
        ">I", header[len(MAGIC):HEADER_SIZE]
    )[0]

    capacity = calculate_capacity(image)

    if message_length > capacity:
        raise ValueError("The hidden message length is invalid.")

    message_start = header_bit_count
    message_end = message_start + (message_length * 8)

    if message_end > len(channels):
        raise ValueError("The hidden message is incomplete.")

    message_bits = [
        channel & 1 for channel in channels[message_start:message_end]
    ]
    message_bytes = bits_to_bytes(message_bits)

    try:
        message = message_bytes.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError("The hidden message is not valid UTF-8 text.") from error

    print(message)


def build_parser():
    parser = argparse.ArgumentParser(
        description="Encode or decode text using image steganography."
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    encode_parser = subparsers.add_parser(
        "encode",
        help="Hide a message inside a PNG image."
    )
    encode_parser.add_argument("input_image")
    encode_parser.add_argument("output_image")
    encode_parser.add_argument("message")

    decode_parser = subparsers.add_parser(
        "decode",
        help="Extract a hidden message from an encoded image."
    )
    decode_parser.add_argument("input_image")

    return parser


def main():
    parser = build_parser()
    arguments = parser.parse_args()

    try:
        if arguments.command == "encode":
            encode(
                arguments.input_image,
                arguments.output_image,
                arguments.message,
            )
        elif arguments.command == "decode":
            decode(arguments.input_image)

    except ValueError as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())