# Image Steganography Program

## Project

**Project ID:** IP-11783  
**Project Title:** Web Service Open to Malicious Attacks  
**Author:** Anish Akhilesh Gupta

## Purpose

This Python program demonstrates image steganography by hiding a UTF-8 text message inside a PNG image using least significant bit encoding. It can also extract the hidden message from an encoded image.

## Features

- Encodes text inside a PNG image.
- Decodes the exact hidden message.
- Preserves the image dimensions.
- Does not modify the original image.
- Prevents the output from overwriting the source image.
- Rejects messages that exceed image capacity.
- Rejects images without a supported hidden message.
- Provides automated tests for the main requirements.

## Requirements

- Python 3
- Pillow 12.0.0

Install the required dependency from PowerShell:

```powershell
python -m pip install -r requirements.txt
```

## Encode a Message

Run the following command from the main project folder:

```powershell
python src\stego.py encode tests\cover.png output\encoded.png "Cloud Counselage Internship Program"
```

Expected output:

```text
Message encoded successfully: [output file path]
Message length: 35 bytes
Image capacity: 149989 bytes
```

## Decode a Message

```powershell
python src\stego.py decode output\encoded.png
```

Expected output:

```text
Cloud Counselage Internship Program
```

## Run Automated Tests

```powershell
python -m unittest discover -s tests -v
```

The test suite verifies:

1. Encode and exact decode round trip
2. Original-image SHA-256 integrity
3. Encoded-image dimensions preserved
4. Unencoded-image rejection
5. Original-image overwrite protection
6. Insufficient-capacity rejection
7. Evidence SHA-256 manifest verification

A successful test execution ends with:

```text
OK
```

## Project Structure

```text
IP-11783_Code_Parth_Nagam/
├── src/
│   └── stego.py
├── tests/
│   ├── test_stego.py
│   ├── cover.png
│   └── tiny.png
├── output/
├── README.md
└── requirements.txt
```

## Security and Technical Notes

- Only lossless PNG output is supported.
- The hidden message is not encrypted.
- Anyone familiar with the encoding format may extract the message.
- Steganography should not be treated as a replacement for encryption.
- JPEG should not be used because lossy compression can destroy hidden data.